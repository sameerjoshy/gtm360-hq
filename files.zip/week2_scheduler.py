"""
backend/scheduler.py
APScheduler configuration for background agent execution
Agents run on defined schedules:
  - Lead Qualification: Every hour
  - Deal Risk: Daily at 8 AM
  - Competitive Intel: Daily at 9 AM
  - Deal Review: Daily at 10 AM
  - Success Plan: On-demand + when new deals close
  - Early Health: Daily at 7 AM
  - Support Triage: Continuous (every 15 min)
  - AE→CS Handover: On-demand + when deals close
  - Churn Risk: Daily at 6 AM
  - EBR Prep: Weekly on Monday at 8 AM
  - Stakeholder Coverage: Weekly on Monday at 9 AM
  - Upsell Signal: Daily at 11 AM
  - Renewal: Daily at 12 PM
  - Advocacy: Weekly on Friday at 10 AM
"""

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime
from backend.agents.orchestrator import get_orchestrator
from backend.utils.logger import log_info, log_error

scheduler = BackgroundScheduler()


def schedule_agent(agent_name: str, trigger):
    """Schedule an agent with a cron trigger"""
    def run_job():
        try:
            log_info(f"[SCHEDULED] Running {agent_name}")
            orchestrator = get_orchestrator()
            result = orchestrator.run_agent(agent_name)
            if result.get("status") == "success":
                log_info(f"[SCHEDULED] {agent_name} completed: {result.get('items_processed', 0)} items")
            else:
                log_error(f"[SCHEDULED] {agent_name} failed: {result.get('error', 'unknown')}")
        except Exception as e:
            log_error(f"[SCHEDULED] {agent_name} error: {e}")
    
    scheduler.add_job(
        run_job,
        trigger=trigger,
        id=f"job_{agent_name.replace(' ', '_')}",
        name=f"Run {agent_name}",
        replace_existing=True
    )


def init_scheduler():
    """Initialize all scheduled jobs"""
    
    # Phase 1: Prospecting
    schedule_agent("lead_qualification", CronTrigger(minute=0))  # Every hour
    schedule_agent("deal_risk", CronTrigger(hour=8, minute=0))   # Daily 8 AM
    schedule_agent("competitive_intel", CronTrigger(hour=9, minute=0))  # Daily 9 AM
    schedule_agent("deal_review", CronTrigger(hour=10, minute=0))  # Daily 10 AM
    
    # Phase 2: Post-Sales
    schedule_agent("early_health", CronTrigger(hour=7, minute=0))  # Daily 7 AM
    schedule_agent("support_triage", CronTrigger(minute="*/15"))  # Every 15 minutes
    schedule_agent("churn_risk", CronTrigger(hour=6, minute=0))  # Daily 6 AM
    schedule_agent("ebr_prep", CronTrigger(day_of_week=0, hour=8, minute=0))  # Monday 8 AM
    schedule_agent("stakeholder_coverage", CronTrigger(day_of_week=0, hour=9, minute=0))  # Monday 9 AM
    
    # Phase 3: Expansion
    schedule_agent("upsell_signal", CronTrigger(hour=11, minute=0))  # Daily 11 AM
    schedule_agent("renewal", CronTrigger(hour=12, minute=0))  # Daily 12 PM
    schedule_agent("advocacy", CronTrigger(day_of_week=4, hour=10, minute=0))  # Friday 10 AM
    
    # Success Plan and AE→CS Handover run on-demand (no schedule)
    
    log_info("Scheduler initialized with 12 jobs")


def start_scheduler():
    """Start the background scheduler"""
    if not scheduler.running:
        init_scheduler()
        scheduler.start()
        log_info("Background scheduler started")


def stop_scheduler():
    """Stop the background scheduler"""
    if scheduler.running:
        scheduler.shutdown()
        log_info("Background scheduler stopped")


def get_scheduler_status() -> dict:
    """Get scheduler status and job list"""
    jobs = []
    for job in scheduler.get_jobs():
        jobs.append({
            "id": job.id,
            "name": job.name,
            "trigger": str(job.trigger),
            "next_run": job.next_run_time.isoformat() if job.next_run_time else None
        })
    
    return {
        "running": scheduler.running,
        "job_count": len(jobs),
        "jobs": jobs
    }
